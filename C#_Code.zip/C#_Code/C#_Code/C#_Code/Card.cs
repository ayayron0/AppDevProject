﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C__Code
{
    internal class Card
    {
        public int Suit { get; }
        public int Value { get; }

        public Card(int suit, int value)
        {
            Suit = suit;
            Value = value;
        }

        public virtual string GetSuitAsString()
        {
            return Suit switch
            {
                1 => "Spades",
                2 => "Hearts",
                3 => "Diamonds",
                4 => "Clubs",
                _ => "Unknown"
            };
        }

        public virtual string GetValueAsString()
        {
            return Value switch
            {
                1 => "Ace",
                11 => "Jack",
                12 => "Queen",
                13 => "King",
                _ => Value.ToString()
            };
        }

        public override string ToString()
        {
            return $"{GetValueAsString()} of {GetSuitAsString()}";
        }
    }
}
