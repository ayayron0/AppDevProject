﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C__Code
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Please enter a name for player 1: ");
            string player1Name = Console.ReadLine();
            Player player1 = new Player(player1Name);

            Console.Write("Please enter a name for player 2: ");
            string player2Name = Console.ReadLine();
            Player player2 = new Player(player2Name);

            Card card1 = null;
            Card card2 = null;
            Deck tableDeck = new Deck(54);

            Deck deck = new Deck();
            for (int s = 0; s <= 3; s++)
            {
                deck.Shuffle();
            }

            for (int i = 0; i < 27; i++)
            {
                player1.PlayerDeck.AddToDeck(deck.DealCard(2 * i));
                player2.PlayerDeck.AddToDeck(deck.DealCard(2 * i + 1));
            }

            Console.WriteLine($"{player1.Name} has {player1.PlayerDeck.NumCards} cards");
            Console.WriteLine($"{player2.Name} has {player2.PlayerDeck.NumCards} cards");

            while (player1.PlayerDeck.NumCards > 0 && player2.PlayerDeck.NumCards > 0)
            {
                Console.WriteLine("Press Enter to deal card");
                string enter1 = Console.ReadLine();
                if (string.IsNullOrEmpty(enter1))
                {
                    card1 = player1.PlayerDeck.DealCard();
                    Console.WriteLine($"{player1.Name}'s card is {card1}\n");
                    tableDeck.AddToDeck(card1);
                }

                Console.WriteLine("Press Enter to deal card");
                string enter2 = Console.ReadLine();
                if (string.IsNullOrEmpty(enter2))
                {
                    card2 = player2.PlayerDeck.DealCard();
                    Console.WriteLine($"{player2.Name}'s card is {card2}\n");
                    tableDeck.AddToDeck(card2);
                }

                if (card1.Value > card2.Value)
                {
                    player1.PlayerDeck.TransferCardsFrom(tableDeck);
                    Console.WriteLine($"{player1.Name} got the cards");
                }
                else if (card2.Value > card1.Value)
                {
                    player2.PlayerDeck.TransferCardsFrom(tableDeck);
                    Console.WriteLine($"{player2.Name} got the cards");
                }
                else
                {
                    Console.WriteLine("It's a tie! Cards remain on the table.");
                }

                Console.WriteLine($"{player1.Name} has {player1.PlayerDeck.NumCards} cards");
                Console.WriteLine($"{player2.Name} has {player2.PlayerDeck.NumCards} cards");
            }

            if (player1.PlayerDeck.NumCards == 0)
                Console.WriteLine($"{player2.Name} wins the game!");
            else if (player2.PlayerDeck.NumCards == 0)
                Console.WriteLine($"{player1.Name} wins the game!");
        }
    }
}