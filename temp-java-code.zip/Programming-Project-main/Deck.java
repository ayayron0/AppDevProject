//Arend Markies section 1 
public class Deck{
    private Card[] deck;
    private int numCards;

    public Deck(){
        int position = 0;
        deck = new Card[54];
        for(int i = 1; i <= 4; i++){
            for(int j = 1; j <= 13; j++){
                Card myCard = new Card(i,j);
                deck[position++] = myCard;
            }
        }
        deck[52] = new Joker(1);
        deck[53] = new Joker(2);
        numCards = 54;
    }
    public void shuffle() {
        for ( int i = deck.length-1; i > 0; i-- ) {
            int rand = (int)(Math.random()*(i+1));
            Card temp = deck[i];
            deck[i] = deck[rand];
            deck[rand] = temp;
        }
    }
    public Deck(int deckSize){
        deck = new Card[deckSize];
        numCards = 0;
    }
    public void addToDeck(Card card){
        if(numCards < 54){
            deck[numCards] = card;
            numCards++;
        }
    }
    public void printDeck(){
        if(numCards <= 0){
            System.out.println("Empty deck");
        }else{
            for(int h = 0; h < numCards; h++){
            System.out.println(deck[h]);
            }
        }
    }
    public Card dealCard(int position){
        return deck[position];
    }
    public Card dealCard(){
        if(numCards >= 0){
            return deck[--numCards];
        }else{
            System.out.println("Empty deck");
            return null;
        }
    }
    public int getNumCards(){
        return numCards;
    }
    // New method to transfer cards from one deck to the bottom of this deck
    public void transferCardsFrom(Deck fromDeck) {
        // Transfer all cards from the source deck (fromDeck) to the bottom of the current deck
        while (fromDeck.getNumCards() > 0) {
            this.addToDeck(fromDeck.dealCard());
        }
    }
    public void transferCardsToBottom(Deck fromDeck) {
        // Transfer all cards from the source deck (fromDeck) to the bottom of the current deck
        while (fromDeck.getNumCards() > 0) {
            this.addToDeck(fromDeck.dealCard());
        }
    }
}