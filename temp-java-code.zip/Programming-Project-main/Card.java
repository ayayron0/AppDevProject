//Andy Rivera section 1 
public class Card {
    private int suit; 
    private int value; 

    public Card(int suit, int value) {
        this.value = value;
        this.suit = suit;
    }

    public int getSuit() {
        return suit;
    }

    public int getValue() {
        return value;
    }

    public String getSuitAsString() {
        switch (suit) {
            case 1: return "Spades";
            case 2: return "Hearts";
            case 3: return "Diamonds";
            case 4: return "Clubs";
        }
         return "Unknown";
    }

    public String getValueAsString() {
        switch (value) {
            case 1: return "Ace";//ace
            case 11: return "Jack";//jack
            case 12: return "Queen";// queen
            case 13: return "King";//king
            default: return String.valueOf(value);//numbers between 2-10
        }
    }

    public String toString() {
        return getValueAsString() + " of " + getSuitAsString();//value + of + suit
    }
}
