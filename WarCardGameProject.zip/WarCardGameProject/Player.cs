﻿namespace WarCardGameProject
{
    public class Player
    {
        public string Name { get; }
        public Deck PlayerDeck { get; }

        public Player(string name)
        {
            Name = name;
            PlayerDeck = new Deck();
        }
    }
}
