﻿using System;
using System.Collections.Generic;

namespace WarCardGameProject
{
    public class WarGame
    {
        public Player Player1 { get; private set; }
        public Player Player2 { get; private set; }

        private List<Card> tablePile;

        public void StartGame(string p1Name, string p2Name)
        {
            Player1 = new Player(p1Name);
            Player2 = new Player(p2Name);

            List<Card> fullDeck = Deck.CreateFullDeck();
            Deck.Shuffle(fullDeck);

            for (int i = 0; i < fullDeck.Count; i++)
            {
                if (i % 2 == 0)
                    Player1.PlayerDeck.AddToBottom(fullDeck[i]);
                else
                    Player2.PlayerDeck.AddToBottom(fullDeck[i]);
            }
        }

        // ------------------------------
        //  CARD COMPARISON for joker
        // ------------------------------
        private int Compare(Card c1, Card c2)
        {
            if (c1 is Joker && c2 is Joker)
                return 0; // JOKER WAR

            if (c1 is Joker)
                return 1;

            if (c2 is Joker)
                return -1;

            return c1.Value.CompareTo(c2.Value);
        }

        private bool IsWar(Card c1, Card c2)
        {
            // Joker vs Joker triggers WAR
            if (c1 is Joker && c2 is Joker)
                return true;

            if (c1 is Joker || c2 is Joker)
                return false; // Joker AUTO wins, no war

            return c1.Value == c2.Value;
        }

        // ------------------------------
        //  MAIN ROUND
        // ------------------------------
        public RoundResults PlayRound()
        {
            var result = new RoundResults();
            tablePile = new List<Card>();

            if (Player1.PlayerDeck.NumCards == 0)
            {
                result.GameOver = true;
                result.Winner = Player2.Name;
                return result;
            }

            if (Player2.PlayerDeck.NumCards == 0)
            {
                result.GameOver = true;
                result.Winner = Player1.Name;
                return result;
            }

            Card c1 = Player1.PlayerDeck.DrawTop();
            Card c2 = Player2.PlayerDeck.DrawTop();

            tablePile.Add(c1);
            tablePile.Add(c2);

            result.Player1Card = c1;
            result.Player2Card = c2;

            if (IsWar(c1, c2))
            {
                result.IsWar = true;
                result.Message = "WAR!";
                return ResolveWar(result);
            }

            int compare = Compare(c1, c2);
            if (compare > 0)
            {
                Player1.PlayerDeck.AddRangeToBottom(tablePile);
                result.Message = $"{Player1.Name} wins the round!";
            }
            else
            {
                Player2.PlayerDeck.AddRangeToBottom(tablePile);
                result.Message = $"{Player2.Name} wins the round!";
            }

            return result;
        }

        // ------------------------------
        //  WAR LOGIC (WITH CARDS RETURNED FOR ANIMATION)
        // ------------------------------
        private RoundResults ResolveWar(RoundResults result)
        {
            // 3 FACE-DOWN CARDS
            for (int i = 0; i < 3; i++)
            {
                if (Player1.PlayerDeck.NumCards > 0)
                {
                    Card fd1 = Player1.PlayerDeck.DrawTop();
                    tablePile.Add(fd1);
                    result.WarFaceDownP1.Add(fd1);
                }

                if (Player2.PlayerDeck.NumCards > 0)
                {
                    Card fd2 = Player2.PlayerDeck.DrawTop();
                    tablePile.Add(fd2);
                    result.WarFaceDownP2.Add(fd2);
                }
            }

            // PLAYER RUNS OUT → LOSES
            if (Player1.PlayerDeck.NumCards == 0)
            {
                result.GameOver = true;
                result.Winner = Player2.Name;
                return result;
            }

            if (Player2.PlayerDeck.NumCards == 0)
            {
                result.GameOver = true;
                result.Winner = Player1.Name;
                return result;
            }

            // FINAL WAR CARDS
            Card c1 = Player1.PlayerDeck.DrawTop();
            Card c2 = Player2.PlayerDeck.DrawTop();

            tablePile.Add(c1);
            tablePile.Add(c2);

            result.Player1Card = c1;
            result.Player2Card = c2;

            // DOUBLE WAR
            if (IsWar(c1, c2))
                return ResolveWar(result);

            int compare = Compare(c1, c2);

            if (compare > 0)
            {
                Player1.PlayerDeck.AddRangeToBottom(tablePile);
                result.Message = $"{Player1.Name} wins the WAR!";
            }
            else
            {
                Player2.PlayerDeck.AddRangeToBottom(tablePile);
                result.Message = $"{Player2.Name} wins the WAR!";
            }

            return result;
        }
    }
}
