﻿using System.Drawing;
using System.Windows.Forms;

namespace WarCardGameProject
{
    partial class SettingForm
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Label lblP1;
        private System.Windows.Forms.Label lblP2;
        private System.Windows.Forms.TextBox txtP1Name;
        private System.Windows.Forms.TextBox txtP2Name;
        private System.Windows.Forms.Button musicToggleButton;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.Button backButton;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SettingForm));
            this.lblP1 = new System.Windows.Forms.Label();
            this.lblP2 = new System.Windows.Forms.Label();
            this.txtP1Name = new System.Windows.Forms.TextBox();
            this.txtP2Name = new System.Windows.Forms.TextBox();
            this.musicToggleButton = new System.Windows.Forms.Button();
            this.saveButton = new System.Windows.Forms.Button();
            this.backButton = new System.Windows.Forms.Button();
            this.languagePanel = new System.Windows.Forms.Panel();
            this.languageLabel = new System.Windows.Forms.Label();
            this.englishRadioButton = new System.Windows.Forms.RadioButton();
            this.frenchRadioButton = new System.Windows.Forms.RadioButton();
            this.spanishRadioButton = new System.Windows.Forms.RadioButton();
            this.languagePanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblP1
            // 
            this.lblP1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            resources.ApplyResources(this.lblP1, "lblP1");
            this.lblP1.ForeColor = System.Drawing.Color.Gold;
            this.lblP1.Name = "lblP1";
            // 
            // lblP2
            // 
            this.lblP2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            resources.ApplyResources(this.lblP2, "lblP2");
            this.lblP2.ForeColor = System.Drawing.Color.Gold;
            this.lblP2.Name = "lblP2";
            // 
            // txtP1Name
            // 
            this.txtP1Name.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.txtP1Name.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.txtP1Name, "txtP1Name");
            this.txtP1Name.ForeColor = System.Drawing.Color.White;
            this.txtP1Name.Name = "txtP1Name";
            // 
            // txtP2Name
            // 
            this.txtP2Name.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.txtP2Name.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.txtP2Name, "txtP2Name");
            this.txtP2Name.ForeColor = System.Drawing.Color.White;
            this.txtP2Name.Name = "txtP2Name";
            // 
            // musicToggleButton
            // 
            this.musicToggleButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.musicToggleButton.FlatAppearance.BorderColor = System.Drawing.Color.Gold;
            this.musicToggleButton.FlatAppearance.BorderSize = 2;
            resources.ApplyResources(this.musicToggleButton, "musicToggleButton");
            this.musicToggleButton.ForeColor = System.Drawing.Color.White;
            this.musicToggleButton.Name = "musicToggleButton";
            this.musicToggleButton.UseVisualStyleBackColor = false;
            this.musicToggleButton.Click += new System.EventHandler(this.musicToggleButton_Click);
            // 
            // saveButton
            // 
            this.saveButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.saveButton.FlatAppearance.BorderColor = System.Drawing.Color.Gold;
            this.saveButton.FlatAppearance.BorderSize = 2;
            resources.ApplyResources(this.saveButton, "saveButton");
            this.saveButton.ForeColor = System.Drawing.Color.White;
            this.saveButton.Name = "saveButton";
            this.saveButton.UseVisualStyleBackColor = false;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // backButton
            // 
            this.backButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.backButton.Cursor = System.Windows.Forms.Cursors.Default;
            this.backButton.FlatAppearance.BorderColor = System.Drawing.Color.DarkRed;
            this.backButton.FlatAppearance.BorderSize = 2;
            resources.ApplyResources(this.backButton, "backButton");
            this.backButton.ForeColor = System.Drawing.Color.White;
            this.backButton.Name = "backButton";
            this.backButton.UseVisualStyleBackColor = false;
            this.backButton.Click += new System.EventHandler(this.backButton_Click);
            // 
            // languagePanel
            // 
            this.languagePanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.languagePanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.languagePanel.Controls.Add(this.languageLabel);
            this.languagePanel.Controls.Add(this.englishRadioButton);
            this.languagePanel.Controls.Add(this.frenchRadioButton);
            this.languagePanel.Controls.Add(this.spanishRadioButton);
            resources.ApplyResources(this.languagePanel, "languagePanel");
            this.languagePanel.Name = "languagePanel";
            // 
            // languageLabel
            // 
            this.languageLabel.BackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.languageLabel, "languageLabel");
            this.languageLabel.ForeColor = System.Drawing.Color.Gold;
            this.languageLabel.Name = "languageLabel";
            // 
            // englishRadioButton
            // 
            resources.ApplyResources(this.englishRadioButton, "englishRadioButton");
            this.englishRadioButton.ForeColor = System.Drawing.Color.White;
            this.englishRadioButton.Name = "englishRadioButton";
            this.englishRadioButton.Click += new System.EventHandler(this.ChangeLanguage);
            // 
            // frenchRadioButton
            // 
            resources.ApplyResources(this.frenchRadioButton, "frenchRadioButton");
            this.frenchRadioButton.ForeColor = System.Drawing.Color.White;
            this.frenchRadioButton.Name = "frenchRadioButton";
            this.frenchRadioButton.Click += new System.EventHandler(this.ChangeLanguage);
            // 
            // spanishRadioButton
            // 
            resources.ApplyResources(this.spanishRadioButton, "spanishRadioButton");
            this.spanishRadioButton.ForeColor = System.Drawing.Color.White;
            this.spanishRadioButton.Name = "spanishRadioButton";
            this.spanishRadioButton.Click += new System.EventHandler(this.ChangeLanguage);
            // 
            // SettingForm
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::WarCardGameProject.Properties.Resources.menu_bg;
            this.Controls.Add(this.languagePanel);
            this.Controls.Add(this.lblP1);
            this.Controls.Add(this.lblP2);
            this.Controls.Add(this.txtP1Name);
            this.Controls.Add(this.txtP2Name);
            this.Controls.Add(this.musicToggleButton);
            this.Controls.Add(this.saveButton);
            this.Controls.Add(this.backButton);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "SettingForm";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.RedirectOnClosing);
            this.languagePanel.ResumeLayout(false);
            this.languagePanel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }


        #endregion

        private Panel languagePanel;
        private Label languageLabel;
        private RadioButton englishRadioButton;
        private RadioButton frenchRadioButton;
        private RadioButton spanishRadioButton;
    }
}
