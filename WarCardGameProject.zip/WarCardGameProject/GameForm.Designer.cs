﻿using System.Windows.Forms;

namespace WarCardGameProject
{
    partial class GameForm
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Label lblPlayer1;
        private System.Windows.Forms.Label lblPlayer2;
        private System.Windows.Forms.Label lblP1Deck;
        private System.Windows.Forms.Label lblP2Deck;
        private System.Windows.Forms.Label lblRoundsLeft;
        private System.Windows.Forms.Label lblWar;
        private System.Windows.Forms.Label lblRoundWinner;


        private System.Windows.Forms.PictureBox picP1Card; 
        private System.Windows.Forms.PictureBox picP2Card;
        private PictureBox picWarP1;
        private PictureBox picWarP2;


        private System.Windows.Forms.Button btnPlay;
        private System.Windows.Forms.Button btnRestart;
        private System.Windows.Forms.Button btnMenu;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GameForm));
            this.lblPlayer1 = new System.Windows.Forms.Label();
            this.lblPlayer2 = new System.Windows.Forms.Label();
            this.lblP1Deck = new System.Windows.Forms.Label();
            this.lblP2Deck = new System.Windows.Forms.Label();
            this.lblRoundsLeft = new System.Windows.Forms.Label();
            this.lblWar = new System.Windows.Forms.Label();
            this.picP1Card = new System.Windows.Forms.PictureBox();
            this.picP2Card = new System.Windows.Forms.PictureBox();
            this.btnPlay = new System.Windows.Forms.Button();
            this.btnRestart = new System.Windows.Forms.Button();
            this.btnMenu = new System.Windows.Forms.Button();
            this.lblRoundWinner = new System.Windows.Forms.Label();
            this.picWarP1 = new System.Windows.Forms.PictureBox();
            this.picWarP2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picP1Card)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picP2Card)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picWarP1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picWarP2)).BeginInit();
            this.SuspendLayout();
            // 
            // lblPlayer1
            // 
            resources.ApplyResources(this.lblPlayer1, "lblPlayer1");
            this.lblPlayer1.BackColor = System.Drawing.Color.Transparent;
            this.lblPlayer1.ForeColor = System.Drawing.Color.White;
            this.lblPlayer1.Name = "lblPlayer1";
            // 
            // lblPlayer2
            // 
            resources.ApplyResources(this.lblPlayer2, "lblPlayer2");
            this.lblPlayer2.BackColor = System.Drawing.Color.Transparent;
            this.lblPlayer2.ForeColor = System.Drawing.Color.White;
            this.lblPlayer2.Name = "lblPlayer2";
            // 
            // lblP1Deck
            // 
            resources.ApplyResources(this.lblP1Deck, "lblP1Deck");
            this.lblP1Deck.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.lblP1Deck.ForeColor = System.Drawing.Color.Gold;
            this.lblP1Deck.Name = "lblP1Deck";
            // 
            // lblP2Deck
            // 
            resources.ApplyResources(this.lblP2Deck, "lblP2Deck");
            this.lblP2Deck.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.lblP2Deck.ForeColor = System.Drawing.Color.Gold;
            this.lblP2Deck.Name = "lblP2Deck";
            // 
            // lblRoundsLeft
            // 
            resources.ApplyResources(this.lblRoundsLeft, "lblRoundsLeft");
            this.lblRoundsLeft.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.lblRoundsLeft.ForeColor = System.Drawing.Color.White;
            this.lblRoundsLeft.Name = "lblRoundsLeft";
            // 
            // lblWar
            // 
            resources.ApplyResources(this.lblWar, "lblWar");
            this.lblWar.BackColor = System.Drawing.Color.Transparent;
            this.lblWar.ForeColor = System.Drawing.Color.Snow;
            this.lblWar.Name = "lblWar";
            // 
            // picP1Card
            // 
            resources.ApplyResources(this.picP1Card, "picP1Card");
            this.picP1Card.BackColor = System.Drawing.Color.Transparent;
            this.picP1Card.Name = "picP1Card";
            this.picP1Card.TabStop = false;
            // 
            // picP2Card
            // 
            resources.ApplyResources(this.picP2Card, "picP2Card");
            this.picP2Card.BackColor = System.Drawing.Color.Transparent;
            this.picP2Card.Name = "picP2Card";
            this.picP2Card.TabStop = false;
            // 
            // btnPlay
            // 
            resources.ApplyResources(this.btnPlay, "btnPlay");
            this.btnPlay.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.btnPlay.FlatAppearance.BorderColor = System.Drawing.Color.Gold;
            this.btnPlay.FlatAppearance.BorderSize = 2;
            this.btnPlay.ForeColor = System.Drawing.Color.White;
            this.btnPlay.Name = "btnPlay";
            this.btnPlay.UseVisualStyleBackColor = false;
            this.btnPlay.Click += new System.EventHandler(this.btnPlay_Click);
            // 
            // btnRestart
            // 
            resources.ApplyResources(this.btnRestart, "btnRestart");
            this.btnRestart.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.btnRestart.FlatAppearance.BorderColor = System.Drawing.Color.Gold;
            this.btnRestart.FlatAppearance.BorderSize = 2;
            this.btnRestart.ForeColor = System.Drawing.Color.White;
            this.btnRestart.Name = "btnRestart";
            this.btnRestart.UseVisualStyleBackColor = false;
            this.btnRestart.Click += new System.EventHandler(this.btnRestart_Click);
            // 
            // btnMenu
            // 
            resources.ApplyResources(this.btnMenu, "btnMenu");
            this.btnMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnMenu.FlatAppearance.BorderColor = System.Drawing.Color.DarkRed;
            this.btnMenu.FlatAppearance.BorderSize = 2;
            this.btnMenu.ForeColor = System.Drawing.Color.White;
            this.btnMenu.Name = "btnMenu";
            this.btnMenu.UseVisualStyleBackColor = false;
            this.btnMenu.Click += new System.EventHandler(this.btnMenu_Click);
            // 
            // lblRoundWinner
            // 
            resources.ApplyResources(this.lblRoundWinner, "lblRoundWinner");
            this.lblRoundWinner.BackColor = System.Drawing.Color.Transparent;
            this.lblRoundWinner.ForeColor = System.Drawing.Color.Gold;
            this.lblRoundWinner.Name = "lblRoundWinner";
            // 
            // picWarP1
            // 
            resources.ApplyResources(this.picWarP1, "picWarP1");
            this.picWarP1.BackColor = System.Drawing.Color.Transparent;
            this.picWarP1.Name = "picWarP1";
            this.picWarP1.TabStop = false;
            // 
            // picWarP2
            // 
            resources.ApplyResources(this.picWarP2, "picWarP2");
            this.picWarP2.BackColor = System.Drawing.Color.Transparent;
            this.picWarP2.Name = "picWarP2";
            this.picWarP2.TabStop = false;
            // 
            // GameForm
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::WarCardGameProject.Properties.Resources.game_bg;
            this.Controls.Add(this.picWarP1);
            this.Controls.Add(this.picWarP2);
            this.Controls.Add(this.lblRoundWinner);
            this.Controls.Add(this.lblPlayer1);
            this.Controls.Add(this.lblPlayer2);
            this.Controls.Add(this.lblP1Deck);
            this.Controls.Add(this.lblP2Deck);
            this.Controls.Add(this.lblRoundsLeft);
            this.Controls.Add(this.lblWar);
            this.Controls.Add(this.picP1Card);
            this.Controls.Add(this.picP2Card);
            this.Controls.Add(this.btnPlay);
            this.Controls.Add(this.btnRestart);
            this.Controls.Add(this.btnMenu);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "GameForm";
            this.Load += new System.EventHandler(this.GameForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picP1Card)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picP2Card)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picWarP1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picWarP2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
    }
}
