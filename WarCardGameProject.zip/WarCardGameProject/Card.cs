﻿namespace WarCardGameProject
{
    public class Card
    {
        public int Suit { get; }
        public int Value { get; }

        public Card(int suit, int value)
        {
            Suit = suit;
            Value = value;
        }

        private string GetSuitLetter()
        {
            switch (Suit)
            {
                case 1: return "S"; // Spades
                case 2: return "H"; // Hearts
                case 3: return "D"; // Diamonds
                case 4: return "C"; // Clubs
                default: return "";
            }
        }

        private string GetRankString()
        {
            switch (Value)
            {
                case 1: return "A";
                case 11: return "J";
                case 12: return "Q";
                case 13: return "K";
                default: return Value.ToString();
            }
        }

        // File name used for animations and image loading
        public virtual string FileName
        {
            get
            {
                return GetRankString() + GetSuitLetter();
            }
        }

        public override string ToString()
        {
            return $"{GetRankString()}{GetSuitLetter()}";
        }
    }
}
