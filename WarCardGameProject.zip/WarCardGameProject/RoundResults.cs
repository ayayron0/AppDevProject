﻿using System.Collections.Generic;

namespace WarCardGameProject
{
    public class RoundResults
    {
        public Card Player1Card;
        public Card Player2Card;

        public List<Card> WarFaceDownP1 = new List<Card>();
        public List<Card> WarFaceDownP2 = new List<Card>();

        public bool IsWar;
        public bool GameOver;
        public string Winner;
        public string Message;
    }
}
