﻿namespace WarCardGameProject
{
    partial class InfoForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Button backButton;
        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.PictureBox logoPicture;
        private System.Windows.Forms.Label infoLabel;
        private System.Windows.Forms.Label namesLabel;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(InfoForm));
            this.backButton = new System.Windows.Forms.Button();
            this.titleLabel = new System.Windows.Forms.Label();
            this.logoPicture = new System.Windows.Forms.PictureBox();
            this.infoLabel = new System.Windows.Forms.Label();
            this.namesLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.logoPicture)).BeginInit();
            this.SuspendLayout();
            // 
            // backButton
            // 
            resources.ApplyResources(this.backButton, "backButton");
            this.backButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.backButton.FlatAppearance.BorderColor = System.Drawing.Color.Gold;
            this.backButton.FlatAppearance.BorderSize = 2;
            this.backButton.ForeColor = System.Drawing.Color.White;
            this.backButton.Name = "backButton";
            this.backButton.UseVisualStyleBackColor = false;
            this.backButton.Click += new System.EventHandler(this.backButton_Click);
            // 
            // titleLabel
            // 
            resources.ApplyResources(this.titleLabel, "titleLabel");
            this.titleLabel.BackColor = System.Drawing.Color.Transparent;
            this.titleLabel.ForeColor = System.Drawing.Color.Gold;
            this.titleLabel.Name = "titleLabel";
            // 
            // logoPicture
            // 
            resources.ApplyResources(this.logoPicture, "logoPicture");
            this.logoPicture.BackColor = System.Drawing.Color.Transparent;
            this.logoPicture.Image = global::WarCardGameProject.Properties.Resources.cegep_logo;
            this.logoPicture.Name = "logoPicture";
            this.logoPicture.TabStop = false;
            // 
            // infoLabel
            // 
            resources.ApplyResources(this.infoLabel, "infoLabel");
            this.infoLabel.BackColor = System.Drawing.Color.Transparent;
            this.infoLabel.ForeColor = System.Drawing.Color.White;
            this.infoLabel.Name = "infoLabel";
            // 
            // namesLabel
            // 
            resources.ApplyResources(this.namesLabel, "namesLabel");
            this.namesLabel.BackColor = System.Drawing.Color.Transparent;
            this.namesLabel.ForeColor = System.Drawing.Color.Gold;
            this.namesLabel.Name = "namesLabel";
            // 
            // InfoForm
            // 
            resources.ApplyResources(this, "$this");
            this.BackgroundImage = global::WarCardGameProject.Properties.Resources.info_bg;
            this.Controls.Add(this.namesLabel);
            this.Controls.Add(this.infoLabel);
            this.Controls.Add(this.logoPicture);
            this.Controls.Add(this.titleLabel);
            this.Controls.Add(this.backButton);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "InfoForm";
            ((System.ComponentModel.ISupportInitialize)(this.logoPicture)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
    }
}
