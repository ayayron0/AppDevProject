﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Globalization;
using System.Media;
using System.Threading;
using System.Windows.Forms;

namespace WarCardGameProject
{
    public partial class SettingForm : Form
    {
        public static string P1Name = "Player 1";
        public static string P2Name = "Player 2";

        // Saved states BEFORE entering settings
        public static bool SavedMusicSetting = true;
        public static CultureInfo savedUILanguage = Thread.CurrentThread.CurrentUICulture;

        private SoundPlayer hoverSound = new SoundPlayer(Properties.Resources.hover);
        private SoundPlayer clickSound = new SoundPlayer(Properties.Resources.click);

        public SettingForm()
        {
            InitializeComponent();

            // Load names
            txtP1Name.Text = P1Name;
            txtP2Name.Text = P2Name;

            if (PlayStyleOptionForm.SelectedMode == "PVB")
            {
                txtP2Name.Text = "Bot";
                txtP2Name.Enabled = false;
            }

            // Load the temporary state (same as MusicManager initially)
            MusicState(CheckLanguage());

            // Set SavedMusicSetting to the real current setting
            SavedMusicSetting = MusicManager.MusicOn;

            // Button styling
            AttachButtonEffects(saveButton, Color.FromArgb(30, 30, 30), Color.Gold);
            AttachButtonEffects(musicToggleButton, Color.FromArgb(30, 30, 30), Color.Gold);
            AttachButtonEffects(backButton, Color.FromArgb(90, 0, 0), Color.DarkRed);

            CheckLanguage();
        }

        // ============================================================
        // SAVE BUTTON — Applies settings permanently
        // ============================================================
        private void saveButton_Click(object sender, EventArgs e)
        {
            // Save names
            P1Name = txtP1Name.Text;

            if (PlayStyleOptionForm.SelectedMode == "PVP")
                P2Name = txtP2Name.Text;
            else
                P2Name = "Bot";

            // Save music state permanently
            SavedMusicSetting = MusicManager.MusicOn;

            //Save laguage state permanently
            savedUILanguage = CheckLanguage();
            //this.Owner.ReloadLanguage(); //not working yet
            this.Owner.Refresh();

            RedirectOnClosing(null, null); //Calls the method to close this form
            this.Close(); //closes the form manuelly
        }

        // ============================================================
        // BACK BUTTON — Cancels settings and restores original music
        // ============================================================
        private void backButton_Click(object sender, EventArgs e)
        {
            // Restore original settings
            MusicManager.Set(SavedMusicSetting);
            Thread.CurrentThread.CurrentUICulture = savedUILanguage;

            RedirectOnClosing(null, null); //Calls the method to close this form
            this.Close(); //closes the form manuelly
        }

        // ============================================================
        // MUSIC TOGGLE BUTTON — Only temporary until saved
        // ============================================================
        private void musicToggleButton_Click(object sender, EventArgs e)
        {
            MusicManager.Toggle();
            MusicState(CheckLanguage());
        }

        // ============================================================
        // BUTTON FX
        // ============================================================
        private void AttachButtonEffects(Button btn, Color normalBack, Color normalBorder)
        {
            btn.MouseEnter += (s, e) =>
            {
                try { hoverSound.Play(); } catch { }
                btn.BackColor = Color.FromArgb(50, 50, 50);
                btn.FlatAppearance.BorderColor = Color.White;
            };

            btn.MouseLeave += (s, e) =>
            {
                btn.BackColor = normalBack;
                btn.FlatAppearance.BorderColor = normalBorder;
            };

            btn.MouseDown += (s, e) =>
            {
                try { clickSound.Play(); } catch { }
                btn.BackColor = Color.FromArgb(70, 70, 70);
            };

            btn.MouseUp += (s, e) =>
            {
                btn.BackColor = Color.FromArgb(50, 50, 50);
            };
        }

        //changes the forms language when the radio buttons are clicked
        private void ChangeLanguage(object sender, EventArgs e)
        {
            if (frenchRadioButton.Checked) //makes the form french if frenchRadioButton is checked from the click
            {
                Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo("fr-CA");
            }
            else if (spanishRadioButton.Checked) //makes the form spanish if spanishRadioButton is checked from the click
            {
                Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo("es-ES");
            }
            else //makes the form default to english from the click
            {
                Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo("en-CA");
            }

            ReloadLanguage(); //makes the form into the checked language
            CheckLanguage(); //re-checkes the radio button that matches the form's language
        }

        //changes the form's language
        public void ReloadLanguage()
        {
            ComponentResourceManager resouces = new ComponentResourceManager(GetType());

            foreach (Control uI in this.Controls)
            {
                resouces.ApplyResources(uI, uI.Name);
            }
        }

        //makes the right radio button checked.
        private CultureInfo CheckLanguage()
        {
            CultureInfo uILanguage = CultureInfo.CurrentUICulture;
            if (uILanguage.Name == "fr-CA")
            {
                frenchRadioButton.Checked = true;
            }
            else if (uILanguage.Name == "es-ES")
            {
                spanishRadioButton.Checked = true;
            }
            else
            {
                englishRadioButton.Checked = true;
            }

            return uILanguage;
        }

        //sets the 
        private void MusicState(CultureInfo currentLanguage)
        {
            if (currentLanguage.Name == "fr-CA")
            {
                musicToggleButton.Text = MusicManager.MusicOn ? "Musique : ACTIVÉE" : "Musique : DÉSACTIVÉE";
            }
            else if (currentLanguage.Name == "es-ES")
            {
                musicToggleButton.Text = MusicManager.MusicOn ? "Music: ON" : "Music: OFF";
            }
            else
            {
                musicToggleButton.Text = MusicManager.MusicOn ? "Music: ON" : "Music: OFF";
            }
        }

        private void RedirectOnClosing(object sender, FormClosingEventArgs e)
        {
            this.Owner.Show();
        }
    }
}
