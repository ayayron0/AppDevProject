﻿using System;
using System.Windows.Forms;

namespace WarCardGameProject
{
    public partial class EndForm : Form
    {
        private string winnerName;

        public EndForm(string winner)
        {
            InitializeComponent();
            winnerName = winner;
        }

        private void EndForm_Load(object sender, EventArgs e)
        {
            // Display winner (you will add the label in designer)
          //  winnerLabel.Text = winnerName + " wins the game!";
        }

        private void backButton_Click(object sender, EventArgs e)
        {
            MainMenuForm menu = new MainMenuForm();
            menu.Show();
            this.Hide();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
