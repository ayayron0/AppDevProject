﻿using System;
using System.Windows.Forms;

namespace WarCardGameProject
{
    public partial class EndForm : Form
    {
        private string winnerName;
        private string loserName;
        private int winnerScore;
        private int loserScore;

        public EndForm(string winner, string loser, int winnerDeck, int loserDeck)
        {
            InitializeComponent();

            winnerName = winner;
            loserName = loser;
            winnerScore = winnerDeck;
            loserScore = loserDeck;

            UpdateLabels();
        }

        private void UpdateLabels()
        {
            statusLabel.Text = $"{winnerName} Wins!";
            scorelabel.Text = "Final Deck Counts";

            p1ScoreLabel.Text = $"{winnerName}: {winnerScore} cards";
            p2ScoreLabel.Text = $"{loserName}: {loserScore} cards";
        }

        private void restartButton_Click(object sender, EventArgs e)
        {
            PlayStyleOptionForm f = new PlayStyleOptionForm();
            f.Owner = this.Owner;
            f.Show();
            this.Close();
        }

        private void returnButton_Click(object sender, EventArgs e)
        {
            this.Owner.Show();
            MusicManager.Play(Application.StartupPath + @"\Assets\menu_music.wav", 0.5f);
            this.Close();
        }

        private void EndForm_Load(object sender, EventArgs e)
        {
            MusicManager.Play(Application.StartupPath + @"\Assets\end.wav", 0.4f);
        }
    }
}
