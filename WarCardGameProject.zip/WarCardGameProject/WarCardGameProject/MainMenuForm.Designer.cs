﻿namespace WarCardGameProject
{
    partial class MainMenuForm
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Button playButton;
        private System.Windows.Forms.Button aboutButton;
        private System.Windows.Forms.Button settingButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.PictureBox titlePicture;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainMenuForm));
            this.playButton = new System.Windows.Forms.Button();
            this.aboutButton = new System.Windows.Forms.Button();
            this.settingButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.titlePicture = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.titlePicture)).BeginInit();
            this.SuspendLayout();
            // 
            // playButton
            // 
            this.playButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.playButton.FlatAppearance.BorderColor = System.Drawing.Color.Gold;
            this.playButton.FlatAppearance.BorderSize = 2;
            resources.ApplyResources(this.playButton, "playButton");
            this.playButton.ForeColor = System.Drawing.Color.White;
            this.playButton.Name = "playButton";
            this.playButton.UseVisualStyleBackColor = false;
            this.playButton.Click += new System.EventHandler(this.playButton_Click);
            // 
            // aboutButton
            // 
            this.aboutButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.aboutButton.FlatAppearance.BorderColor = System.Drawing.Color.Gold;
            this.aboutButton.FlatAppearance.BorderSize = 2;
            resources.ApplyResources(this.aboutButton, "aboutButton");
            this.aboutButton.ForeColor = System.Drawing.Color.White;
            this.aboutButton.Name = "aboutButton";
            this.aboutButton.UseVisualStyleBackColor = false;
            this.aboutButton.Click += new System.EventHandler(this.aboutButton_Click);
            // 
            // settingButton
            // 
            this.settingButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.settingButton.FlatAppearance.BorderColor = System.Drawing.Color.Gold;
            this.settingButton.FlatAppearance.BorderSize = 2;
            resources.ApplyResources(this.settingButton, "settingButton");
            this.settingButton.ForeColor = System.Drawing.Color.White;
            this.settingButton.Name = "settingButton";
            this.settingButton.UseVisualStyleBackColor = false;
            this.settingButton.Click += new System.EventHandler(this.settingButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.exitButton.FlatAppearance.BorderColor = System.Drawing.Color.DarkRed;
            this.exitButton.FlatAppearance.BorderSize = 2;
            resources.ApplyResources(this.exitButton, "exitButton");
            this.exitButton.ForeColor = System.Drawing.Color.White;
            this.exitButton.Name = "exitButton";
            this.exitButton.UseVisualStyleBackColor = false;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // titlePicture
            // 
            this.titlePicture.BackColor = System.Drawing.Color.Transparent;
            this.titlePicture.Image = global::WarCardGameProject.Properties.Resources.title;
            resources.ApplyResources(this.titlePicture, "titlePicture");
            this.titlePicture.Name = "titlePicture";
            this.titlePicture.TabStop = false;
            // 
            // MainMenuForm
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::WarCardGameProject.Properties.Resources.menu_bg;
            this.Controls.Add(this.titlePicture);
            this.Controls.Add(this.playButton);
            this.Controls.Add(this.aboutButton);
            this.Controls.Add(this.settingButton);
            this.Controls.Add(this.exitButton);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "MainMenuForm";
            this.VisibleChanged += new System.EventHandler(this.ReloadLanguage);
            ((System.ComponentModel.ISupportInitialize)(this.titlePicture)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
    }
}
