﻿using System.Windows.Forms;

namespace WarCardGameProject
{
    partial class GameForm
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Label lblPlayer1;
        private System.Windows.Forms.Label lblPlayer2;
        private System.Windows.Forms.Label lblP1Deck;
        private System.Windows.Forms.Label lblP2Deck;
        private System.Windows.Forms.Label lblRoundsLeft;
        private System.Windows.Forms.Label lblWar;
        private System.Windows.Forms.Label lblRoundWinner;


        private System.Windows.Forms.PictureBox picP1Card; 
        private System.Windows.Forms.PictureBox picP2Card;
        private PictureBox picWarP1;
        private PictureBox picWarP2;


        private System.Windows.Forms.Button btnPlay;
        private System.Windows.Forms.Button btnRestart;
        private System.Windows.Forms.Button btnMenu;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.lblPlayer1 = new System.Windows.Forms.Label();
            this.lblPlayer2 = new System.Windows.Forms.Label();
            this.lblP1Deck = new System.Windows.Forms.Label();
            this.lblP2Deck = new System.Windows.Forms.Label();
            this.lblRoundsLeft = new System.Windows.Forms.Label();
            this.lblWar = new System.Windows.Forms.Label();
            this.picP1Card = new System.Windows.Forms.PictureBox();
            this.picP2Card = new System.Windows.Forms.PictureBox();
            this.btnPlay = new System.Windows.Forms.Button();
            this.btnRestart = new System.Windows.Forms.Button();
            this.btnMenu = new System.Windows.Forms.Button();
            this.lblRoundWinner = new System.Windows.Forms.Label();
            this.picWarP1 = new System.Windows.Forms.PictureBox();
            this.picWarP2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picP1Card)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picP2Card)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picWarP1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picWarP2)).BeginInit();
            this.SuspendLayout();
            // 
            // lblPlayer1
            // 
            this.lblPlayer1.BackColor = System.Drawing.Color.Transparent;
            this.lblPlayer1.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.lblPlayer1.ForeColor = System.Drawing.Color.White;
            this.lblPlayer1.Location = new System.Drawing.Point(80, 40);
            this.lblPlayer1.Name = "lblPlayer1";
            this.lblPlayer1.Size = new System.Drawing.Size(200, 40);
            this.lblPlayer1.TabIndex = 0;
            this.lblPlayer1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblPlayer2
            // 
            this.lblPlayer2.BackColor = System.Drawing.Color.Transparent;
            this.lblPlayer2.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.lblPlayer2.ForeColor = System.Drawing.Color.White;
            this.lblPlayer2.Location = new System.Drawing.Point(750, 40);
            this.lblPlayer2.Name = "lblPlayer2";
            this.lblPlayer2.Size = new System.Drawing.Size(200, 40);
            this.lblPlayer2.TabIndex = 1;
            this.lblPlayer2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblP1Deck
            // 
            this.lblP1Deck.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.lblP1Deck.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.lblP1Deck.ForeColor = System.Drawing.Color.Gold;
            this.lblP1Deck.Location = new System.Drawing.Point(80, 90);
            this.lblP1Deck.Name = "lblP1Deck";
            this.lblP1Deck.Size = new System.Drawing.Size(200, 30);
            this.lblP1Deck.TabIndex = 2;
            this.lblP1Deck.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblP2Deck
            // 
            this.lblP2Deck.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.lblP2Deck.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.lblP2Deck.ForeColor = System.Drawing.Color.Gold;
            this.lblP2Deck.Location = new System.Drawing.Point(750, 90);
            this.lblP2Deck.Name = "lblP2Deck";
            this.lblP2Deck.Size = new System.Drawing.Size(200, 30);
            this.lblP2Deck.TabIndex = 3;
            this.lblP2Deck.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblRoundsLeft
            // 
            this.lblRoundsLeft.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.lblRoundsLeft.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.lblRoundsLeft.ForeColor = System.Drawing.Color.White;
            this.lblRoundsLeft.Location = new System.Drawing.Point(410, 40);
            this.lblRoundsLeft.Name = "lblRoundsLeft";
            this.lblRoundsLeft.Size = new System.Drawing.Size(200, 40);
            this.lblRoundsLeft.TabIndex = 4;
            this.lblRoundsLeft.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblWar
            // 
            this.lblWar.BackColor = System.Drawing.Color.Transparent;
            this.lblWar.Font = new System.Drawing.Font("Segoe UI", 32F, System.Drawing.FontStyle.Bold);
            this.lblWar.ForeColor = System.Drawing.Color.Snow;
            this.lblWar.Location = new System.Drawing.Point(424, 101);
            this.lblWar.Name = "lblWar";
            this.lblWar.Size = new System.Drawing.Size(260, 70);
            this.lblWar.TabIndex = 5;
            this.lblWar.Text = "WAR!";
            this.lblWar.Visible = false;
            // 
            // picP1Card
            // 
            this.picP1Card.BackColor = System.Drawing.Color.Transparent;
            this.picP1Card.Location = new System.Drawing.Point(150, 200);
            this.picP1Card.Name = "picP1Card";
            this.picP1Card.Size = new System.Drawing.Size(180, 230);
            this.picP1Card.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picP1Card.TabIndex = 6;
            this.picP1Card.TabStop = false;
            // 
            // picP2Card
            // 
            this.picP2Card.BackColor = System.Drawing.Color.Transparent;
            this.picP2Card.Location = new System.Drawing.Point(690, 200);
            this.picP2Card.Name = "picP2Card";
            this.picP2Card.Size = new System.Drawing.Size(180, 230);
            this.picP2Card.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picP2Card.TabIndex = 7;
            this.picP2Card.TabStop = false;
            // 
            // btnPlay
            // 
            this.btnPlay.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.btnPlay.FlatAppearance.BorderColor = System.Drawing.Color.Gold;
            this.btnPlay.FlatAppearance.BorderSize = 2;
            this.btnPlay.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPlay.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.btnPlay.ForeColor = System.Drawing.Color.White;
            this.btnPlay.Location = new System.Drawing.Point(120, 470);
            this.btnPlay.Name = "btnPlay";
            this.btnPlay.Size = new System.Drawing.Size(220, 55);
            this.btnPlay.TabIndex = 8;
            this.btnPlay.Text = "PLAY ROUND";
            this.btnPlay.UseVisualStyleBackColor = false;
            this.btnPlay.Click += new System.EventHandler(this.btnPlay_Click);
            // 
            // btnRestart
            // 
            this.btnRestart.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.btnRestart.FlatAppearance.BorderColor = System.Drawing.Color.Gold;
            this.btnRestart.FlatAppearance.BorderSize = 2;
            this.btnRestart.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRestart.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.btnRestart.ForeColor = System.Drawing.Color.White;
            this.btnRestart.Location = new System.Drawing.Point(400, 470);
            this.btnRestart.Name = "btnRestart";
            this.btnRestart.Size = new System.Drawing.Size(220, 55);
            this.btnRestart.TabIndex = 9;
            this.btnRestart.Text = "RESTART";
            this.btnRestart.UseVisualStyleBackColor = false;
            this.btnRestart.Click += new System.EventHandler(this.btnRestart_Click);
            // 
            // btnMenu
            // 
            this.btnMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnMenu.FlatAppearance.BorderColor = System.Drawing.Color.DarkRed;
            this.btnMenu.FlatAppearance.BorderSize = 2;
            this.btnMenu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMenu.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.btnMenu.ForeColor = System.Drawing.Color.White;
            this.btnMenu.Location = new System.Drawing.Point(680, 470);
            this.btnMenu.Name = "btnMenu";
            this.btnMenu.Size = new System.Drawing.Size(220, 55);
            this.btnMenu.TabIndex = 10;
            this.btnMenu.Text = "MENU";
            this.btnMenu.UseVisualStyleBackColor = false;
            this.btnMenu.Click += new System.EventHandler(this.btnMenu_Click);
            // 
            // lblRoundWinner
            // 
            this.lblRoundWinner.BackColor = System.Drawing.Color.Transparent;
            this.lblRoundWinner.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.lblRoundWinner.ForeColor = System.Drawing.Color.Gold;
            this.lblRoundWinner.Location = new System.Drawing.Point(350, 320);
            this.lblRoundWinner.Name = "lblRoundWinner";
            this.lblRoundWinner.Size = new System.Drawing.Size(334, 110);
            this.lblRoundWinner.TabIndex = 99;
            this.lblRoundWinner.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // picWarP1
            // 
            this.picWarP1.BackColor = System.Drawing.Color.Transparent;
            this.picWarP1.Location = new System.Drawing.Point(348, 174);
            this.picWarP1.Name = "picWarP1";
            this.picWarP1.Size = new System.Drawing.Size(100, 140);
            this.picWarP1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picWarP1.TabIndex = 0;
            this.picWarP1.TabStop = false;
            this.picWarP1.Visible = false;
            // 
            // picWarP2
            // 
            this.picWarP2.BackColor = System.Drawing.Color.Transparent;
            this.picWarP2.Location = new System.Drawing.Point(572, 174);
            this.picWarP2.Name = "picWarP2";
            this.picWarP2.Size = new System.Drawing.Size(100, 140);
            this.picWarP2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picWarP2.TabIndex = 1;
            this.picWarP2.TabStop = false;
            this.picWarP2.Visible = false;
            // 
            // GameForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::WarCardGameProject.Properties.Resources.game_bg;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1024, 576);
            this.Controls.Add(this.picWarP1);
            this.Controls.Add(this.picWarP2);
            this.Controls.Add(this.lblRoundWinner);
            this.Controls.Add(this.lblPlayer1);
            this.Controls.Add(this.lblPlayer2);
            this.Controls.Add(this.lblP1Deck);
            this.Controls.Add(this.lblP2Deck);
            this.Controls.Add(this.lblRoundsLeft);
            this.Controls.Add(this.lblWar);
            this.Controls.Add(this.picP1Card);
            this.Controls.Add(this.picP2Card);
            this.Controls.Add(this.btnPlay);
            this.Controls.Add(this.btnRestart);
            this.Controls.Add(this.btnMenu);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "GameForm";
            this.Text = "War - Game";
            this.Load += new System.EventHandler(this.GameForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picP1Card)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picP2Card)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picWarP1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picWarP2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
    }
}
