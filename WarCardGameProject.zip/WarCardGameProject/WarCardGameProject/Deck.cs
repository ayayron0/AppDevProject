﻿using System;
using System.Collections.Generic;

namespace WarCardGameProject
{
    public class Deck
    {
        private Queue<Card> cards = new Queue<Card>();

        public int NumCards => cards.Count;

        public Deck() { }

        public Deck(IEnumerable<Card> initialCards)
        {
            foreach (var c in initialCards)
                cards.Enqueue(c);
        }

        public void AddToBottom(Card card)
        {
            cards.Enqueue(card);
        }

        public Card DrawTop()
        {
            return cards.Count > 0 ? cards.Dequeue() : null;
        }

        public void AddRangeToBottom(IEnumerable<Card> pile)
        {
            foreach (var card in pile)
                cards.Enqueue(card);
        }

        public static List<Card> CreateFullDeck()
        {
            var list = new List<Card>();

            for (int suit = 1; suit <= 4; suit++)
                for (int value = 1; value <= 13; value++)
                    list.Add(new Card(suit, value));

            // Jokers
            list.Add(new Joker(1));
            list.Add(new Joker(2));

            return list;
        }

        public static void Shuffle(List<Card> list)
        {
            Random r = new Random();
            for (int i = list.Count - 1; i > 0; i--)
            {
                int j = r.Next(i + 1);
                (list[i], list[j]) = (list[j], list[i]);
            }
        }
    }
}
