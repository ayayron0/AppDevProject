﻿namespace WarCardGameProject
{
    public class Joker : Card
    {
        public int JokerId { get; }

        public Joker(int id) : base(0, 0)
        {
            JokerId = id;
        }

        public override string FileName
        {
            get
            {
                if (JokerId == 1)
                    return "JokerRed";
                else
                    return "JokerBlack";
            }
        }
    }
}
