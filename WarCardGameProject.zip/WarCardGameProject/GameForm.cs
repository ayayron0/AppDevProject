﻿using System;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Media;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WarCardGameProject
{
    public partial class GameForm : Form
    {
        public static CultureInfo language = Thread.CurrentThread.CurrentUICulture;

        private string gameMode;
        private int totalRounds;
        private int currentRound = 0;

        private SoundPlayer sfxDraw = new SoundPlayer(Properties.Resources.draw);
        private SoundPlayer sfxFlip = new SoundPlayer(Properties.Resources.flip);
        private SoundPlayer warSFX = new SoundPlayer(Properties.Resources.war);

        private bool isPaused = false;
        private bool isAnimating = false;

        private WarGame game;

        public GameForm(string mode, int rounds)
        {
            InitializeComponent();
            this.DoubleBuffered = true;

            gameMode = mode;
            totalRounds = rounds;
        }

        private void GameForm_Load(object sender, EventArgs e)
        {
            MusicManager.Play(Application.StartupPath + @"\Assets\gameplay.wav", 0.4f);
            StartNewGame();
        }

        // ------------------------------
        //  START GAME
        // ------------------------------
        private void StartNewGame()
        {
            game = new WarGame();

            if (gameMode == "PVB")
                game.StartGame(SettingForm.P1Name, "Bot");
            else
                game.StartGame(SettingForm.P1Name, SettingForm.P2Name);

            lblPlayer1.Text = game.Player1.Name;
            lblPlayer2.Text = game.Player2.Name;

            currentRound = 0;
            if (language.Name == "fr-CA") //if french, set text in french
            {
                lblRoundsLeft.Text = "Tours Restants: ";
            }
            else if (language.Name == "es-US") //if spanish, set text in spanish
            {
                lblRoundsLeft.Text = "Rondas Restantes: ";
            }
            else //defaults text in english
            {
                lblRoundsLeft.Text = "Rounds Left: ";
            }
            lblRoundsLeft.Text += totalRounds;

            picP1Card.Image = null;
            picP2Card.Image = null;

            lblWar.Visible = false;
            lblRoundWinner.Text = string.Empty;

            // hide war pile cards if visible
            picWarP1.Visible = false;
            picWarP2.Visible = false;

            UpdateUI();
        }

        // ------------------------------
        //  PLAY ROUND (ANIMATION)
        // ------------------------------
        private async void btnPlay_Click(object sender, EventArgs e)
        {
            if (isPaused) return;
            if (isAnimating) return;   // prevent spam
            isAnimating = true;

            // If all rounds finished
            if (currentRound >= totalRounds)
            {
                if (language.Name == "fr-CA") //if french, set text in french
                {
                    MessageBox.Show("Tous les tours terminés!");
                }
                else if (language.Name == "es-US") //if spanish, set text in spanish
                {
                    MessageBox.Show("¡Todas las rondas completadas!");
                }
                else //defaults text in english
                {
                    MessageBox.Show("All rounds completed!");
                }

                EndGame();
                isAnimating = false;
                return;
            }

            currentRound++;

            // Play 1 round
            RoundResults result = game.PlayRound();

            // Clear previous war visuals
            picWarP1.Visible = false;
            picWarP2.Visible = false;

            if (result.IsWar)
            {
                // WAR ANIMATION (face-down cards to table)
                await AnimateWar(result);

                // Now flip the final deciding cards for each player
                await AnimateCard(picP1Card, result.Player1Card);
                await AnimateCard(picP2Card, result.Player2Card);

                lblWar.Visible = true;
                lblRoundWinner.Text = result.Message; // e.g. "Aaron wins the WAR!"
            }
            else
            {
                // Normal round: just flip the 2 cards
                lblWar.Visible = false;

                await AnimateCard(picP1Card, result.Player1Card);
                await AnimateCard(picP2Card, result.Player2Card);

                lblRoundWinner.Text = result.Message; // e.g. "Aaron wins the round."
            }

            UpdateUI();

            // End game if someone lost their deck
            if (result.GameOver)
            {
                EndGame(result.Winner);
            }

            isAnimating = false;
        }

        // ------------------------------
        //  IMAGE LOADING: FILENAMES MAPPING
        // ------------------------------
        private string GetCardImageFile(Card c)
        {
            // Joker check
            if (c is Joker)
            {
                if (c.Suit == 1) return "JokerRed.png";
                else return "JokerBlack.png";
            }

            // SUIT → letter
            string suitLetter = "X";
            if (c.Suit == 1) suitLetter = "S";
            else if (c.Suit == 2) suitLetter = "H";
            else if (c.Suit == 3) suitLetter = "D";
            else if (c.Suit == 4) suitLetter = "C";

            // VALUE → letter/number
            string valueLetter = "";
            if (c.Value == 1) valueLetter = "A";
            else if (c.Value == 11) valueLetter = "J";
            else if (c.Value == 12) valueLetter = "Q";
            else if (c.Value == 13) valueLetter = "K";
            else valueLetter = c.Value.ToString();

            return valueLetter + suitLetter + ".png";
        }

        // ------------------------------
        //  CARD FLIP ANIMATION
        // ------------------------------
        private async Task AnimateCard(PictureBox pic, Card card)
        {
            // play draw sound at start
            try { sfxDraw.Play(); } catch { }

            int originalWidth = pic.Width;
            int originalLeft = pic.Left;

            // 1. SHRINK WIDTH (start flip)
            for (int w = originalWidth; w > 10; w -= 10)
            {
                pic.Width = w;
                pic.Left = originalLeft + (originalWidth - w) / 2;
                await Task.Delay(10);
            }

            // 2. LOAD IMAGE
            string fileName = GetCardImageFile(card);
            string imagePath = Path.Combine(Application.StartupPath, "img", "cards", fileName);

            if (File.Exists(imagePath))
            {
                using (var bmpTemp = new Bitmap(imagePath))
                    pic.Image = new Bitmap(bmpTemp);
            }
            else
            {
                pic.Image = null;
            }

            // Flip sound
            try { sfxFlip.Play(); } catch { }

            // 3. EXPAND BACK
            for (int w = 10; w <= originalWidth; w += 10)
            {
                pic.Width = w;
                pic.Left = originalLeft + (originalWidth - w) / 2;
                await Task.Delay(10);
            }

            pic.Width = originalWidth;
            pic.Left = originalLeft;
        }

        // ------------------------------
        //  WAR ANIMATION (face-down cards to center)
        // ------------------------------
        private async Task AnimateWar(RoundResults result)
        {
            lblWar.Visible = true;
            try { warSFX.Play(); } catch { }

            Bitmap backImage = Properties.Resources.back;  // make sure back.png exists in resources

            // animate three cards from each player
            for (int i = 0; i < result.WarFaceDownP1.Count; i++)
            {
                picWarP1.Image = backImage;
                picWarP2.Image = backImage;

                picWarP1.Visible = true;
                picWarP2.Visible = true;

                // stack them slightly
                int offset = i * 8;
                picWarP1.Top = 180 + offset;
                picWarP2.Top = 180 + offset;

                // fade/slide in
                picWarP1.Width = 10;
                picWarP1.Left = 350 + 45;
                picWarP2.Width = 10;
                picWarP2.Left = 570 + 45;

                for (int w = 10; w <= 100; w += 10)
                {
                    picWarP1.Width = w;
                    picWarP1.Left = 350 + (100 - w) / 2;

                    picWarP2.Width = w;
                    picWarP2.Left = 570 + (100 - w) / 2;

                    await Task.Delay(10);
                }

                await Task.Delay(150);
            }

            // suspense pause
            await Task.Delay(300);
        }

        // ------------------------------
        // UPDATE UI
        // ------------------------------
        private void UpdateUI()
        {
            if (language.Name == "fr-CA") //if french, set text in french
            {
                lblP1Deck.Text = "Paquet: ";
                lblP2Deck.Text = "Paquet: ";
            }
            else if (language.Name == "es-US") //if spanish, set text in spanish
            {
                lblP1Deck.Text = "Mazo: ";
                lblP2Deck.Text = "Mazo: ";
            }
            else //defaults text in english
            {
                lblP1Deck.Text = "Deck: ";
                lblP2Deck.Text = "Deck: ";
            }
            lblP1Deck.Text += game.Player1.PlayerDeck.NumCards;
            lblP2Deck.Text += game.Player2.PlayerDeck.NumCards;

            int roundsLeft = totalRounds - currentRound;
            if (language.Name == "fr-CA") //if french, set text in french
            {
                lblRoundsLeft.Text = "Tours Restants: ";
            }
            else if (language.Name == "es-US") //if spanish, set text in spanish
            {
                lblRoundsLeft.Text = "Rondas Restantes: ";
            }
            else //defaults text in english
            {
                lblRoundsLeft.Text = "Rounds Left: ";
            }
            lblRoundsLeft.Text += roundsLeft;

            if (roundsLeft <= 0)
                EndGame();
        }

        // ------------------------------
        // RESTART GAME
        // ------------------------------
        private void btnRestart_Click(object sender, EventArgs e)
        {
            StartNewGame();
        }

        // ------------------------------
        // END GAME
        // ------------------------------
        private void EndGame(string winner = null)
        {
            string p1 = game.Player1.Name;
            string p2 = game.Player2.Name;

            int p1Deck = game.Player1.PlayerDeck.NumCards;
            int p2Deck = game.Player2.PlayerDeck.NumCards;

            if (winner == null)
            {
                winner = (p1Deck > p2Deck) ? p1 : p2;
            }

            string loser = (winner == p1) ? p2 : p1;

            EndForm end = new EndForm(
                winner,
                loser,
                (winner == p1) ? p1Deck : p2Deck,
                (winner == p1) ? p2Deck : p1Deck
            );

            end.Owner = this.Owner;
            end.Show();
            this.Close();
        }

        // ------------------------------
        // BACK TO MENU
        // ------------------------------
        private void btnMenu_Click(object sender, EventArgs e)
        {
            this.Owner.Show();
            this.Close();
        }
    }
}
