﻿using System;
using System.Windows.Forms;

namespace WarCardGameProject
{
    public partial class GameForm : Form
    {
        private string gameMode;
        private int totalRounds;
        private int currentRound = 0;

        private WarGame game;  

        public GameForm(string mode, int rounds)
        {
            InitializeComponent();
            gameMode = mode;
            totalRounds = rounds;
        }

        private void GameForm_Load(object sender, EventArgs e)
        {
            game = new WarGame();

            if (gameMode == "PVB")
            {
                game.StartGame(SettingForm.P1Name, "Bot");
            }
            else
            {
                game.StartGame(SettingForm.P1Name, SettingForm.P2Name);
            }

            UpdateUI();
        }

        private void nextRoundButton_Click(object sender, EventArgs e)
        {
            if (currentRound >= totalRounds)
            {
                MessageBox.Show("All rounds completed!");
                EndGame();
                return;
            }

            currentRound++;

            RoundResult result = game.PlayRound();

            // Example UI updates (your designer will add actual labels)
         //   player1CardLabel.Text = result.Player1Card.ToString();
          //  player2CardLabel.Text = result.Player2Card.ToString();

          //  roundLogTextBox.AppendText($"Round {currentRound}: {result.Message}\n");

            UpdateUI();

            if (result.GameOver)
            {
                EndGame(result.Winner);
            }
        }

        private void UpdateUI()
        {
        //    p1CardCountLabel.Text = game.Player1.PlayerDeck.NumCards.ToString();
      //      p2CardCountLabel.Text = game.Player2.PlayerDeck.NumCards.ToString();
       //     roundCounterLabel.Text = $"Round: {currentRound}/{totalRounds}";
        }

        private void EndGame(string winner = null)
        {
            if (winner == null)
            {
                winner = game.Player1.PlayerDeck.NumCards > game.Player2.PlayerDeck.NumCards
                    ? game.Player1.Name
                    : game.Player2.Name;
            }

            EndForm end = new EndForm(winner);
            end.Show();
            this.Hide();
        }

        private void backButton_Click(object sender, EventArgs e)
        {
            MainMenuForm menu = new MainMenuForm();
            menu.Show();
            this.Hide();
        }
    }
}
