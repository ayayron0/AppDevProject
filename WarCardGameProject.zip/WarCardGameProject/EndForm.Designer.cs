﻿namespace WarCardGameProject
{
    partial class EndForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EndForm));
            this.restartButton = new System.Windows.Forms.Button();
            this.returnButton = new System.Windows.Forms.Button();
            this.titlePicture = new System.Windows.Forms.PictureBox();
            this.modePanel = new System.Windows.Forms.Panel();
            this.p2ScoreLabel = new System.Windows.Forms.Label();
            this.p1ScoreLabel = new System.Windows.Forms.Label();
            this.scorelabel = new System.Windows.Forms.Label();
            this.statusLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.titlePicture)).BeginInit();
            this.modePanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // restartButton
            // 
            resources.ApplyResources(this.restartButton, "restartButton");
            this.restartButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.restartButton.FlatAppearance.BorderColor = System.Drawing.Color.Gold;
            this.restartButton.FlatAppearance.BorderSize = 2;
            this.restartButton.ForeColor = System.Drawing.Color.White;
            this.restartButton.Name = "restartButton";
            this.restartButton.UseVisualStyleBackColor = false;
            this.restartButton.Click += new System.EventHandler(this.restartButton_Click);
            // 
            // returnButton
            // 
            resources.ApplyResources(this.returnButton, "returnButton");
            this.returnButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.returnButton.FlatAppearance.BorderColor = System.Drawing.Color.DarkRed;
            this.returnButton.FlatAppearance.BorderSize = 2;
            this.returnButton.ForeColor = System.Drawing.Color.White;
            this.returnButton.Name = "returnButton";
            this.returnButton.UseVisualStyleBackColor = false;
            this.returnButton.Click += new System.EventHandler(this.returnButton_Click);
            // 
            // titlePicture
            // 
            resources.ApplyResources(this.titlePicture, "titlePicture");
            this.titlePicture.BackColor = System.Drawing.Color.Transparent;
            this.titlePicture.Image = global::WarCardGameProject.Properties.Resources.title;
            this.titlePicture.Name = "titlePicture";
            this.titlePicture.TabStop = false;
            // 
            // modePanel
            // 
            resources.ApplyResources(this.modePanel, "modePanel");
            this.modePanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.modePanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.modePanel.Controls.Add(this.p2ScoreLabel);
            this.modePanel.Controls.Add(this.p1ScoreLabel);
            this.modePanel.Controls.Add(this.scorelabel);
            this.modePanel.Controls.Add(this.statusLabel);
            this.modePanel.Name = "modePanel";
            // 
            // p2ScoreLabel
            // 
            resources.ApplyResources(this.p2ScoreLabel, "p2ScoreLabel");
            this.p2ScoreLabel.ForeColor = System.Drawing.Color.White;
            this.p2ScoreLabel.Name = "p2ScoreLabel";
            // 
            // p1ScoreLabel
            // 
            resources.ApplyResources(this.p1ScoreLabel, "p1ScoreLabel");
            this.p1ScoreLabel.ForeColor = System.Drawing.Color.White;
            this.p1ScoreLabel.Name = "p1ScoreLabel";
            // 
            // scorelabel
            // 
            resources.ApplyResources(this.scorelabel, "scorelabel");
            this.scorelabel.BackColor = System.Drawing.Color.Transparent;
            this.scorelabel.ForeColor = System.Drawing.Color.Gold;
            this.scorelabel.Name = "scorelabel";
            // 
            // statusLabel
            // 
            resources.ApplyResources(this.statusLabel, "statusLabel");
            this.statusLabel.BackColor = System.Drawing.Color.Transparent;
            this.statusLabel.ForeColor = System.Drawing.Color.Gold;
            this.statusLabel.Name = "statusLabel";
            // 
            // EndForm
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::WarCardGameProject.Properties.Resources.menu_bg;
            this.Controls.Add(this.modePanel);
            this.Controls.Add(this.titlePicture);
            this.Controls.Add(this.returnButton);
            this.Controls.Add(this.restartButton);
            this.Name = "EndForm";
            this.Load += new System.EventHandler(this.EndForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.titlePicture)).EndInit();
            this.modePanel.ResumeLayout(false);
            this.modePanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button restartButton;
        private System.Windows.Forms.Button returnButton;
        private System.Windows.Forms.PictureBox titlePicture;
        private System.Windows.Forms.Panel modePanel;
        private System.Windows.Forms.Label statusLabel;
        private System.Windows.Forms.Label scorelabel;
        private System.Windows.Forms.Label p1ScoreLabel;
        private System.Windows.Forms.Label p2ScoreLabel;
    }
}