﻿namespace WarCardGameProject
{
    partial class PlayStyleOptionForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.playerNumGroupBox = new System.Windows.Forms.GroupBox();
            this.computerLabel = new System.Windows.Forms.Label();
            this.computerDomainUpDown = new System.Windows.Forms.DomainUpDown();
            this.playerlabel = new System.Windows.Forms.Label();
            this.playerDomainUpDown = new System.Windows.Forms.DomainUpDown();
            this.roundsGroupBox = new System.Windows.Forms.GroupBox();
            this.fifteenRoundsRadioButton = new System.Windows.Forms.RadioButton();
            this.tenRoundsRadioButton = new System.Windows.Forms.RadioButton();
            this.fiveRoundsRadioButton = new System.Windows.Forms.RadioButton();
            this.startButton = new System.Windows.Forms.Button();
            this.backButton = new System.Windows.Forms.Button();
            this.playerNumGroupBox.SuspendLayout();
            this.roundsGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // playerNumGroupBox
            // 
            this.playerNumGroupBox.Controls.Add(this.computerLabel);
            this.playerNumGroupBox.Controls.Add(this.computerDomainUpDown);
            this.playerNumGroupBox.Controls.Add(this.playerlabel);
            this.playerNumGroupBox.Controls.Add(this.playerDomainUpDown);
            this.playerNumGroupBox.Location = new System.Drawing.Point(12, 12);
            this.playerNumGroupBox.Name = "playerNumGroupBox";
            this.playerNumGroupBox.Size = new System.Drawing.Size(131, 86);
            this.playerNumGroupBox.TabIndex = 3;
            this.playerNumGroupBox.TabStop = false;
            this.playerNumGroupBox.Text = "Number of players:";
            // 
            // computerLabel
            // 
            this.computerLabel.AutoSize = true;
            this.computerLabel.Location = new System.Drawing.Point(64, 29);
            this.computerLabel.Name = "computerLabel";
            this.computerLabel.Size = new System.Drawing.Size(57, 13);
            this.computerLabel.TabIndex = 3;
            this.computerLabel.Text = "Computers";
            // 
            // computerDomainUpDown
            // 
            this.computerDomainUpDown.Items.Add("0");
            this.computerDomainUpDown.Items.Add("1");
            this.computerDomainUpDown.Items.Add("2");
            this.computerDomainUpDown.Items.Add("3");
            this.computerDomainUpDown.Items.Add("4");
            this.computerDomainUpDown.Location = new System.Drawing.Point(67, 51);
            this.computerDomainUpDown.Name = "computerDomainUpDown";
            this.computerDomainUpDown.Size = new System.Drawing.Size(42, 20);
            this.computerDomainUpDown.TabIndex = 2;
            this.computerDomainUpDown.Text = "0";
            // 
            // playerlabel
            // 
            this.playerlabel.AutoSize = true;
            this.playerlabel.Location = new System.Drawing.Point(7, 29);
            this.playerlabel.Name = "playerlabel";
            this.playerlabel.Size = new System.Drawing.Size(41, 13);
            this.playerlabel.TabIndex = 1;
            this.playerlabel.Text = "Players";
            // 
            // playerDomainUpDown
            // 
            this.playerDomainUpDown.Items.Add("0");
            this.playerDomainUpDown.Items.Add("1");
            this.playerDomainUpDown.Items.Add("2");
            this.playerDomainUpDown.Items.Add("3");
            this.playerDomainUpDown.Items.Add("4");
            this.playerDomainUpDown.Location = new System.Drawing.Point(10, 51);
            this.playerDomainUpDown.Name = "playerDomainUpDown";
            this.playerDomainUpDown.Size = new System.Drawing.Size(42, 20);
            this.playerDomainUpDown.TabIndex = 0;
            this.playerDomainUpDown.Text = "0";
            // 
            // roundsGroupBox
            // 
            this.roundsGroupBox.Controls.Add(this.fifteenRoundsRadioButton);
            this.roundsGroupBox.Controls.Add(this.tenRoundsRadioButton);
            this.roundsGroupBox.Controls.Add(this.fiveRoundsRadioButton);
            this.roundsGroupBox.Location = new System.Drawing.Point(12, 104);
            this.roundsGroupBox.Name = "roundsGroupBox";
            this.roundsGroupBox.Size = new System.Drawing.Size(232, 52);
            this.roundsGroupBox.TabIndex = 4;
            this.roundsGroupBox.TabStop = false;
            this.roundsGroupBox.Text = "Number of rounds";
            // 
            // fifteenRoundsRadioButton
            // 
            this.fifteenRoundsRadioButton.AutoSize = true;
            this.fifteenRoundsRadioButton.Location = new System.Drawing.Point(157, 20);
            this.fifteenRoundsRadioButton.Name = "fifteenRoundsRadioButton";
            this.fifteenRoundsRadioButton.Size = new System.Drawing.Size(72, 17);
            this.fifteenRoundsRadioButton.TabIndex = 2;
            this.fifteenRoundsRadioButton.TabStop = true;
            this.fifteenRoundsRadioButton.Text = "15 rounds";
            this.fifteenRoundsRadioButton.UseVisualStyleBackColor = true;
            // 
            // tenRoundsRadioButton
            // 
            this.tenRoundsRadioButton.AutoSize = true;
            this.tenRoundsRadioButton.Location = new System.Drawing.Point(79, 20);
            this.tenRoundsRadioButton.Name = "tenRoundsRadioButton";
            this.tenRoundsRadioButton.Size = new System.Drawing.Size(72, 17);
            this.tenRoundsRadioButton.TabIndex = 1;
            this.tenRoundsRadioButton.TabStop = true;
            this.tenRoundsRadioButton.Text = "10 rounds";
            this.tenRoundsRadioButton.UseVisualStyleBackColor = true;
            // 
            // fiveRoundsRadioButton
            // 
            this.fiveRoundsRadioButton.AutoSize = true;
            this.fiveRoundsRadioButton.Location = new System.Drawing.Point(7, 20);
            this.fiveRoundsRadioButton.Name = "fiveRoundsRadioButton";
            this.fiveRoundsRadioButton.Size = new System.Drawing.Size(66, 17);
            this.fiveRoundsRadioButton.TabIndex = 0;
            this.fiveRoundsRadioButton.TabStop = true;
            this.fiveRoundsRadioButton.Text = "5 rounds";
            this.fiveRoundsRadioButton.UseVisualStyleBackColor = true;
            // 
            // startButton
            // 
            this.startButton.Location = new System.Drawing.Point(12, 172);
            this.startButton.Name = "startButton";
            this.startButton.Size = new System.Drawing.Size(75, 23);
            this.startButton.TabIndex = 5;
            this.startButton.Text = "Start";
            this.startButton.UseVisualStyleBackColor = true;
            this.startButton.Click += new System.EventHandler(this.startButton_Click);
            // 
            // backButton
            // 
            this.backButton.Location = new System.Drawing.Point(166, 172);
            this.backButton.Name = "backButton";
            this.backButton.Size = new System.Drawing.Size(75, 23);
            this.backButton.TabIndex = 6;
            this.backButton.Text = "Back";
            this.backButton.UseVisualStyleBackColor = true;
            this.backButton.Click += new System.EventHandler(this.backButton_Click);
            // 
            // PlayStyleOptionForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(256, 204);
            this.Controls.Add(this.backButton);
            this.Controls.Add(this.startButton);
            this.Controls.Add(this.roundsGroupBox);
            this.Controls.Add(this.playerNumGroupBox);
            this.Name = "PlayStyleOptionForm";
            this.Text = "Game Options";
            this.playerNumGroupBox.ResumeLayout(false);
            this.playerNumGroupBox.PerformLayout();
            this.roundsGroupBox.ResumeLayout(false);
            this.roundsGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.GroupBox playerNumGroupBox;
        private System.Windows.Forms.Label computerLabel;
        private System.Windows.Forms.DomainUpDown computerDomainUpDown;
        private System.Windows.Forms.Label playerlabel;
        private System.Windows.Forms.DomainUpDown playerDomainUpDown;
        private System.Windows.Forms.GroupBox roundsGroupBox;
        private System.Windows.Forms.RadioButton tenRoundsRadioButton;
        private System.Windows.Forms.RadioButton fiveRoundsRadioButton;
        private System.Windows.Forms.RadioButton fifteenRoundsRadioButton;
        private System.Windows.Forms.Button startButton;
        private System.Windows.Forms.Button backButton;
    }
}