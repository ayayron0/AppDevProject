﻿namespace WarCardGameProject
{
    partial class PlayStyleOptionForm
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Panel modePanel;
        private System.Windows.Forms.Panel roundPanel;

        private System.Windows.Forms.Label modeLabel;
        private System.Windows.Forms.Label roundLabel;

        private System.Windows.Forms.RadioButton pvpButton;
        private System.Windows.Forms.RadioButton pvbButton;

        private System.Windows.Forms.RadioButton fiveRounds;
        private System.Windows.Forms.RadioButton tenRounds;
        private System.Windows.Forms.RadioButton fifteenRounds;

        private System.Windows.Forms.Button startButton;
        private System.Windows.Forms.Button backButton;


        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }


        #region Designer Code

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PlayStyleOptionForm));
            this.modePanel = new System.Windows.Forms.Panel();
            this.modeLabel = new System.Windows.Forms.Label();
            this.pvpButton = new System.Windows.Forms.RadioButton();
            this.pvbButton = new System.Windows.Forms.RadioButton();
            this.roundPanel = new System.Windows.Forms.Panel();
            this.roundLabel = new System.Windows.Forms.Label();
            this.fiveRounds = new System.Windows.Forms.RadioButton();
            this.tenRounds = new System.Windows.Forms.RadioButton();
            this.fifteenRounds = new System.Windows.Forms.RadioButton();
            this.startButton = new System.Windows.Forms.Button();
            this.backButton = new System.Windows.Forms.Button();
            this.modePanel.SuspendLayout();
            this.roundPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // modePanel
            // 
            resources.ApplyResources(this.modePanel, "modePanel");
            this.modePanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.modePanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.modePanel.Controls.Add(this.modeLabel);
            this.modePanel.Controls.Add(this.pvpButton);
            this.modePanel.Controls.Add(this.pvbButton);
            this.modePanel.Name = "modePanel";
            // 
            // modeLabel
            // 
            resources.ApplyResources(this.modeLabel, "modeLabel");
            this.modeLabel.BackColor = System.Drawing.Color.Transparent;
            this.modeLabel.ForeColor = System.Drawing.Color.Gold;
            this.modeLabel.Name = "modeLabel";
            // 
            // pvpButton
            // 
            resources.ApplyResources(this.pvpButton, "pvpButton");
            this.pvpButton.BackColor = System.Drawing.Color.Transparent;
            this.pvpButton.ForeColor = System.Drawing.Color.White;
            this.pvpButton.Name = "pvpButton";
            this.pvpButton.UseVisualStyleBackColor = false;
            // 
            // pvbButton
            // 
            resources.ApplyResources(this.pvbButton, "pvbButton");
            this.pvbButton.BackColor = System.Drawing.Color.Transparent;
            this.pvbButton.ForeColor = System.Drawing.Color.White;
            this.pvbButton.Name = "pvbButton";
            this.pvbButton.UseVisualStyleBackColor = false;
            // 
            // roundPanel
            // 
            resources.ApplyResources(this.roundPanel, "roundPanel");
            this.roundPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.roundPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.roundPanel.Controls.Add(this.roundLabel);
            this.roundPanel.Controls.Add(this.fiveRounds);
            this.roundPanel.Controls.Add(this.tenRounds);
            this.roundPanel.Controls.Add(this.fifteenRounds);
            this.roundPanel.Name = "roundPanel";
            // 
            // roundLabel
            // 
            resources.ApplyResources(this.roundLabel, "roundLabel");
            this.roundLabel.BackColor = System.Drawing.Color.Transparent;
            this.roundLabel.ForeColor = System.Drawing.Color.Gold;
            this.roundLabel.Name = "roundLabel";
            // 
            // fiveRounds
            // 
            resources.ApplyResources(this.fiveRounds, "fiveRounds");
            this.fiveRounds.ForeColor = System.Drawing.Color.White;
            this.fiveRounds.Name = "fiveRounds";
            // 
            // tenRounds
            // 
            resources.ApplyResources(this.tenRounds, "tenRounds");
            this.tenRounds.ForeColor = System.Drawing.Color.White;
            this.tenRounds.Name = "tenRounds";
            // 
            // fifteenRounds
            // 
            resources.ApplyResources(this.fifteenRounds, "fifteenRounds");
            this.fifteenRounds.ForeColor = System.Drawing.Color.White;
            this.fifteenRounds.Name = "fifteenRounds";
            // 
            // startButton
            // 
            resources.ApplyResources(this.startButton, "startButton");
            this.startButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.startButton.FlatAppearance.BorderColor = System.Drawing.Color.Gold;
            this.startButton.FlatAppearance.BorderSize = 2;
            this.startButton.ForeColor = System.Drawing.Color.White;
            this.startButton.Name = "startButton";
            this.startButton.UseVisualStyleBackColor = false;
            this.startButton.Click += new System.EventHandler(this.startButton_Click);
            // 
            // backButton
            // 
            resources.ApplyResources(this.backButton, "backButton");
            this.backButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.backButton.FlatAppearance.BorderColor = System.Drawing.Color.DarkRed;
            this.backButton.FlatAppearance.BorderSize = 2;
            this.backButton.ForeColor = System.Drawing.Color.White;
            this.backButton.Name = "backButton";
            this.backButton.UseVisualStyleBackColor = false;
            this.backButton.Click += new System.EventHandler(this.backButton_Click);
            // 
            // PlayStyleOptionForm
            // 
            resources.ApplyResources(this, "$this");
            this.BackgroundImage = global::WarCardGameProject.Properties.Resources.menu_bg;
            this.Controls.Add(this.modePanel);
            this.Controls.Add(this.roundPanel);
            this.Controls.Add(this.startButton);
            this.Controls.Add(this.backButton);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "PlayStyleOptionForm";
            this.Load += new System.EventHandler(this.PlayStyleOptionForm_Load);
            this.modePanel.ResumeLayout(false);
            this.modePanel.PerformLayout();
            this.roundPanel.ResumeLayout(false);
            this.roundPanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
    }
}
